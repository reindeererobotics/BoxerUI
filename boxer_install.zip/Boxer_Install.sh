#!/bin/bash
# This file contains documentation snippets for Linux installation tutorial
if [ "$1" = "--check" ] ; then
sudo()
{
    command $@
}
fi

# Variable for current directory
current_dir=$(pwd)

# [body]
# Install minimal prerequisites (Ubuntu 18.04 as reference)
sudo apt update && sudo apt install -y cmake g++ wget unzip

# Download and unpack sources
wget -O opencv.zip https://github.com/opencv/opencv/archive/master.zip
unzip opencv.zip

# Create build directory
mkdir -p build && cd build

# Configure
cmake  ../opencv-master

# Build
cmake --build .
# [body]


# Install glfw3 library
sudo apt-get install libglfw3-dev

# Provide and launch BoxerUI_app
#echo $current_dir
cd $current_dir
chmod +x BoxerUI_app
./BoxerUI_app
